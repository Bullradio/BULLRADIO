package com.bullradio.app

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.IBinder
import android.view.animation.AnimationUtils
import androidx.appcompat.app.AppCompatActivity
import com.bullradio.app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var radioService: RadioService? = null
    private var isBound = false

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val localBinder = binder as RadioService.LocalBinder
            radioService = localBinder.getService()
            isBound = true
            updateUI(radioService?.isPlaying() == true)
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            isBound = false
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupUI()
        bindRadioService()
    }

    private fun setupUI() {
        // Animazione pulsante play
        binding.btnPlay.setOnClickListener {
            val pulse = AnimationUtils.loadAnimation(this, R.anim.pulse)
            binding.btnPlay.startAnimation(pulse)
            togglePlayback()
        }

        // Info stream
        binding.tvRadioName.text = "BULL RADIO"
        binding.tvSubtitle.text = "The Best Country Music 🤠"
        binding.tvStatus.text = "Premi Play per ascoltare"
    }

    private fun bindRadioService() {
        val intent = Intent(this, RadioService::class.java)
        startService(intent)
        bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)
    }

    private fun togglePlayback() {
        if (isBound) {
            if (radioService?.isPlaying() == true) {
                radioService?.stopStream()
                updateUI(false)
            } else {
                radioService?.playStream(STREAM_URL)
                updateUI(true)
            }
        }
    }

    private fun updateUI(playing: Boolean) {
        if (playing) {
            binding.btnPlay.setImageResource(R.drawable.ic_pause)
            binding.tvStatus.text = "In onda • LIVE"
            binding.waveView.startAnimation(
                AnimationUtils.loadAnimation(this, R.anim.wave_anim)
            )
            binding.ivLogo.startAnimation(
                AnimationUtils.loadAnimation(this, R.anim.slow_rotate)
            )
        } else {
            binding.btnPlay.setImageResource(R.drawable.ic_play)
            binding.tvStatus.text = "Premi Play per ascoltare"
            binding.waveView.clearAnimation()
            binding.ivLogo.clearAnimation()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isBound) {
            unbindService(serviceConnection)
            isBound = false
        }
    }

    companion object {
        const val STREAM_URL = "https://stream.example.com/bullradio" // ← sostituisci con il tuo URL
    }
}
