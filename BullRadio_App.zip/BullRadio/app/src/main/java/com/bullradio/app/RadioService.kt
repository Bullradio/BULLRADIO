package com.bullradio.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Binder
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

class RadioService : Service() {

    private val binder = LocalBinder()
    private var mediaPlayer: MediaPlayer? = null
    private var playing = false

    inner class LocalBinder : Binder() {
        fun getService(): RadioService = this@RadioService
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    fun playStream(url: String) {
        try {
            mediaPlayer?.release()
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                setDataSource(url)
                prepareAsync()
                setOnPreparedListener {
                    start()
                    playing = true
                }
                setOnErrorListener { _, _, _ ->
                    playing = false
                    false
                }
            }
            startForeground(NOTIFICATION_ID, buildNotification(true))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun stopStream() {
        mediaPlayer?.apply {
            if (isPlaying) stop()
            release()
        }
        mediaPlayer = null
        playing = false
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    fun isPlaying(): Boolean = playing && mediaPlayer?.isPlaying == true

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Bull Radio Player",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Controlli riproduzione Bull Radio"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(playing: Boolean): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("🤠 BULL RADIO")
            .setContentText(if (playing) "In onda • LIVE" else "In pausa")
            .setSmallIcon(R.drawable.ic_radio_notification)
            .setContentIntent(pendingIntent)
            .setOngoing(playing)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    override fun onDestroy() {
        stopStream()
        super.onDestroy()
    }

    companion object {
        const val CHANNEL_ID = "bull_radio_channel"
        const val NOTIFICATION_ID = 1
    }
}
