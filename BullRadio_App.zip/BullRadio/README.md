# 🤠 BULL RADIO - App Android

App Android nativa per la web radio country **BULL RADIO**.

---

## 📋 Requisiti

- **Android Studio** (versione Hedgehog o superiore) → https://developer.android.com/studio
- **JDK 17** (incluso in Android Studio)
- **Android SDK** (API 21+)

---

## 🚀 Come aprire e compilare il progetto

### 1. Apri Android Studio
### 2. Importa il progetto
   - File → Open → seleziona la cartella `BullRadio`
   - Attendi la sincronizzazione Gradle (qualche minuto la prima volta)

### 3. Inserisci il tuo URL dello stream
   Apri il file:
   ```
   app/src/main/java/com/bullradio/app/MainActivity.kt
   ```
   Cerca questa riga e sostituisci l'URL:
   ```kotlin
   const val STREAM_URL = "https://stream.example.com/bullradio" // ← IL TUO URL QUI
   ```

### 4. Compila l'APK
   - Build → Build Bundle(s) / APK(s) → Build APK(s)
   - L'APK si trova in: `app/build/outputs/apk/debug/app-debug.apk`

### 5. Installa sul telefono
   - Attiva "Origini sconosciute" nel telefono
   - Copia l'APK e installalo
   - Oppure usa **Run** (▶) per installarlo direttamente via USB

---

## 📱 Funzionalità dell'app

| Feature | Descrizione |
|---------|-------------|
| ▶️ Play/Pause | Avvia/ferma lo streaming |
| 🔔 Notifica | Controlli in background nella barra di notifica |
| 🎵 Background | Continua a suonare anche con lo schermo spento |
| 🐂 Logo animato | Rotazione durante la riproduzione |
| 🌊 Onda animata | Visualizzazione audio in tempo reale |
| 🎨 Tema western | Colori oro e ruggine stile country |

---

## 🎨 Personalizzazione

### Cambia URL stream
In `MainActivity.kt`:
```kotlin
const val STREAM_URL = "https://tuo-server.com/stream"
```

### Formati stream supportati
- MP3 stream (es. `http://stream.server.com/live.mp3`)
- AAC stream
- M3U8 (HLS)
- OGG

### Cambia colori
In `res/values/colors.xml`:
```xml
<color name="gold">#D4A017</color>       <!-- Colore principale -->
<color name="rust">#8B3A0F</color>       <!-- Colore secondario -->
<color name="bg_dark">#1A0E00</color>    <!-- Sfondo scuro -->
```

### Cambia nome radio
In `res/values/strings.xml`:
```xml
<string name="app_name">Bull Radio</string>
```

---

## 📁 Struttura del progetto

```
BullRadio/
├── app/
│   └── src/main/
│       ├── java/com/bullradio/app/
│       │   ├── MainActivity.kt      ← Schermata principale
│       │   └── RadioService.kt      ← Servizio streaming background
│       ├── res/
│       │   ├── layout/
│       │   │   └── activity_main.xml  ← Layout UI
│       │   ├── drawable/              ← Icone e sfondi
│       │   ├── anim/                  ← Animazioni
│       │   └── values/
│       │       ├── colors.xml
│       │       ├── strings.xml
│       │       └── themes.xml
│       └── AndroidManifest.xml
├── build.gradle
├── settings.gradle
└── gradle.properties
```

---

## 🐛 Problemi comuni

**Lo stream non parte?**
→ Verifica che l'URL sia corretto e accessibile
→ Controlla che il telefono abbia connessione internet
→ Alcuni stream HTTP richiedono `android:usesCleartextTraffic="true"` (già incluso)

**La notifica non appare?**
→ Android 13+ richiede il permesso notifiche: accettalo al primo avvio

---

*Sviluppato per BULL RADIO 🤠🎸*
